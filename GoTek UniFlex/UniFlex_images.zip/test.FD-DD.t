++
++ formatfd +d=/dev/fd0 +m=FD-DD
File system name? UniFLEX
Volume name? BlancoFD-DD
Volume number? 77216
About to format "/dev/fd0" as FD-DD    - Continue (y/n)? y

Formatting complete on device "/dev/fd0"

     2 Heads
    77 Cylinders
    16 Sectors/Track
0009A0 Total blocks (hex)
No bad blocks detected
++
++ diskinfo /dev/fd0

Disk Information for "/dev/fd0":
------------------------------------------------
File system name: UniFLEX
Volume name: BlancoFD-DD
Volume number: 11680
Creation date: 14:22:42 Thu May 29 1225
Last update: 14:22:42 Thu May 29 1225

Total disk size: 1.2 Mb (2464 blocks)
 - Fdn space: 37.0 Kb (74 blocks, 592 fdns)
 - File space: 1.2 Mb (2388 blocks)
 - Swap space: 0.0 Kb (0 blocks)

Free space: 1.2 Mb (2387 blocks)
Free fdns: 590

Disk type:  Floppy Disk
            Double sided
            Double density
            Side bits disabled

++
++ devcheck /dev/fd0
Checking device '/dev/fd0'.
  Testing Boot - Block 0
  Testing SIR - Block 1
  Testing FDN space - Blocks 2 through 75 (0x4B)
  Testing Volume space - Blocks 76 (0x4C) through 2463 (0x99F)
  No Swap space
Device check for '/dev/fd0' complete - 0 bad blocks detected.
++
