++
++ formatfd +d/dev/fd0 +m=FD-DS
File system name? UniFLEX
Volume name? BlancoFD-DS
Volume number? 7728
About to format "/dev/fd0" as FD-DS    - Continue (y/n)? y

Formatting complete on device "/dev/fd0"

     2 Heads
    77 Cylinders
     8 Sectors/Track
0004D0 Total blocks (hex)
No bad blocks detected
++
++ diskinfo /dev/fd0

Disk Information for "/dev/fd0":
------------------------------------------------
File system name: UniFLEX
Volume name: BlancoFD-DS
Volume number: 7728
Creation date: 14:12:13 Thu May 29 1225
Last update: 14:12:13 Thu May 29 1225

Total disk size: 616.0 Kb (1232 blocks)
 - Fdn space: 18.5 Kb (37 blocks, 296 fdns)
 - File space: 596.5 Kb (1193 blocks)
 - Swap space: 0.0 Kb (0 blocks)

Free space: 596.0 Kb (1192 blocks)
Free fdns: 294

Disk type:  Floppy Disk
            Double sided
            Single density
            Side bits disabled

++
++ devcheck /dev/fd0
Checking device '/dev/fd0'.
  Testing Boot - Block 0
  Testing SIR - Block 1
  Testing FDN space - Blocks 2 through 38 (0x26)
  Testing Volume space - Blocks 39 (0x27) through 1231 (0x4CF)
  No Swap space
Device check for '/dev/fd0' complete - 0 bad blocks detected.
++
