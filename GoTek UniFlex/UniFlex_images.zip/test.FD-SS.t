++
++ formatfd +d=/dev/fd0 +m=FD-SS
File system name? UniFLEX
Volume name? BlancoFD-SS
Volume number? 7718
About to format "/dev/fd0" as FD-SS    - Continue (y/n)? y

Formatting complete on device "/dev/fd0"

     1 Heads
    77 Cylinders
     8 Sectors/Track
000268 Total blocks (hex)
No bad blocks detected
++
++ diskinfo /dev/fd0

Disk Information for "/dev/fd0":
------------------------------------------------
File system name: UniFLEX
Volume name: Blanco FD-SS
Volume number: 7718
Creation date: 13:52:46 Thu May 29 1225
Last update: 13:52:46 Thu May 29 1225

Total disk size: 308.0 Kb (616 blocks)
 - Fdn space: 9.0 Kb (18 blocks, 144 fdns)
 - File space: 298.0 Kb (596 blocks)
 - Swap space: 0.0 Kb (0 blocks)

Free space: 297.5 Kb (595 blocks)
Free fdns: 142

Disk type:  Floppy Disk
            Single sided
            Single density
            Side bits disabled

++
++ devcheck /dev/fd0
Checking device '/dev/fd0'.
  Testing Boot - Block 0
  Testing SIR - Block 1
  Testing FDN space - Blocks 2 through 19 (0x13)
  Testing Volume space - Blocks 20 (0x14) through 615 (0x267)
  No Swap space
Device check for '/dev/fd0' complete - 0 bad blocks detected.
++
